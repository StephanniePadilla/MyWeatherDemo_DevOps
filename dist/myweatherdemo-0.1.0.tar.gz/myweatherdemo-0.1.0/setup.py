# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['connect_myweatherdemo']

package_data = \
{'': ['*']}

install_requires = \
['connect-extension-runner>=23.5']

entry_points = \
{'connect.eaas.ext': ['extension = '
                      'connect_myweatherdemo.extension:MyweatherdemoExtension']}

setup_kwargs = {
    'name': 'myweatherdemo',
    'version': '0.1.0',
    'description': 'MyWeatherDemo test for DevOps',
    'long_description': '# Welcome to MyWeatherDemo !\n\n\nMyWeatherDemo test for DevOps\n\n\n\n## License\n\n**MyWeatherDemo** is licensed under the *Apache Software License 2.0* license.\n\n',
    'author': 'Education Team',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
